const express = require('express');
const app = express();  
app.use(express.json());

let todos = [
    { id: 1, text: 'Изучить Node.js', done: false }
];

let nextId = 2;

// Получить все задачи
app.get('/todos', (req, res) => {
    res.json(todos);
});

// Добавить новую задачу
app.post('/todos', (req, res) => {
    const { text } = req.body;
    if (!text || typeof text !== 'string') {
        return res.status(400).json({ error: "Поле 'text' обязательно и должно быть строкой" });
    }

    const todo = { id: nextId++, text, done: false };
    todos.push(todo);
    res.status(201).json(todo);
});

// Переключить статус done
app.put('/todos/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const todo = todos.find(t => t.id === id);
    if (!todo) return res.status(404).json({ error: 'Задача не найдена' });

    todo.done = !todo.done;
    res.json(todo);
});

// Удалить задачу
app.delete('/todos/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const index = todos.findIndex(t => t.id === id);

    if (index === -1) {
        return res.status(404).json({ error: 'Задача не найдена' });
    }

    const deletedTodo = todos.splice(index, 1)[0];
    res.json({ message: 'Задача удалена', deleted: deletedTodo });
});

const PORT = 4000;
app.listen(PORT, () => {
    console.log(`API запущено: http://localhost:${PORT}`);
    console.log(`Команды для теста`);
    console.log(`curl http://localhost:${PORT}/todos`);
    console.log(`curl -X POST http://localhost:${PORT}/todos -H "Content-Type: application/json" -d '{"text": "Новая задача"}'  `);
    console.log(`curl -X DELETE http://localhost:${PORT}/todos/1`);
});