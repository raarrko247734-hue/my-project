const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.static(__dirname));
app.use(express.json());

app.post('/register', (req, res) => {
  const { nickname, password } = req.body;

  const userData = { nickname, password };
  const filePath = path.join(__dirname, 'users.json');

  let users = [];
  if (fs.existsSync(filePath)) {
    users = JSON.parse(fs.readFileSync(filePath));
  }

  users.push(userData);
  fs.writeFileSync(filePath, JSON.stringify(users, null, 2));

  res.status(200).send('OK');
});

app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});
