const express = require('express');
const app = express();

app.use(express.json());

let books = [
    { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald' },
    { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee' },
    { id: 3, title: '1984', author: 'George Orwell' }
];

app.get('/books', (req, res) => {
    res.json(books);
});

app.get('/books/:id', (req, res) => {
    const id = Number(req.params.id);
    const book = books.find(b => b.id === id);

   if (!book) {
        return res.status(404).json({ message: 'Book not found' });
    }
    res.json(book);
});

app.post('/books', (req, res) => {
    const { title, author, year } = req.body;

    const newBook = {
        id: Date.now(),
        title,
        author,
        year
    };

    books.push(newBook);
    res.status(201).json(newBook);
});

app.put('/books/:id', (req, res) => {
    const id = Number(req.params.id);
    const book = books.find(b => b.id === id);

    if (!book) {
        return res.status(404).json({ message: 'Book not found' });
    }

    const { title, author, year } = req.body;

    book.title = title;
    book.author = author;
    book.year = year;

    res.json(book);
});

app.delete('/books/:id', (req, res) => {
    const id = Number(req.params.id);
    books = books.filter(b => b.id !== id);

    res.json({ message: 'Book deleted' });
});

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});