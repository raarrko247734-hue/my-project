const axios = require('axios');

const users = ['octocat','torvalds','mojombo'];

async function getUsers() {
  try {
    const requests = users.map(username => 
        axios.get(`https://api.github.com/users/${username}`)
        .then(res => res.data)
        .catch(err => {
            console.log(`Ошибка для ${username}:`)
            return null;
  })
);

    const results = await Promise.all(requests);

    const validUsers = results.filter(user => user !== null);

    validUsers.sort((a, b) => b.followers - a.followers);

    console.table(validUsers.map(user => ({
        Login: user.login,
        Name: user.name,
        Repos: user.public_repos,
        Followers: user.followers,
    })));
  } catch (error) {
        console.error('Ошибка при получении данных:', error.message);
    
 }
}
getUsers();